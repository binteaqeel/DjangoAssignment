from . import views
from django.urls import path


from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.home, name='home'),
    path('login/',views.login, name='login'),
    path('signup/',views.signup, name='signup'),
    path('resetPass/',views.resetPass, name='resetPass'),
    path('verify/',views.verify, name='verify'),
    path('Confirm/',views.confirm, name='confirm'),
    path('category/', views.category, name='category'),
    path('add', views.add, name='add'),
    path('edit/<int:id>', views.edit, name='edit'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('product/', views.product, name='product'),
    path('prodadd', views.prodadd, name='prodadd'),
    path('prodedit/<int:id>', views.prodedit, name='prodedit'),
    path('proddelete/<int:id>', views.proddelete, name='proddelete'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
