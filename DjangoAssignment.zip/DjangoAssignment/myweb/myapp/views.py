from django.shortcuts import render, redirect,get_object_or_404
from .models import User,Category,Product
from django.contrib import messages
import re
import bcrypt

def home(request):
    return render(request, 'home.html')

def login(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        
        try: 
            user = User.objects.get(email=email)
            if bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
                request.session['id'] = user.id
                request.session['name'] = user.name
                request.session['email'] = user.email
                return redirect("home")
            else:
                msg = "Invalid username or password"
                messages.error(request, msg)
                return render(request, 'login.html', {'msg': msg})
        except User.DoesNotExist:
            msg = "Invalid username or password"
            messages.error(request, msg)
            return render(request, 'login.html', {'msg': msg})
    else:
        return render(request,'login.html')

def signup(request):
    if request.method == "POST":
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        data = User.objects.filter(email=email).exists()
        if data:
            return render(request, 'signup.html', {'msg': 'Email already exists'})
        
        if len(password) < 8:
            return render(request, 'signup.html', {'msg': 'Password must be at least 8 characters long'})
        if not re.search(r'[A-Z]', password):
            return render(request, 'signup.html', {'msg': 'Password must contain at least one capital letter'})
        if not re.search(r'[a-z]', password):
            return render(request, 'signup.html', {'msg': 'Password must contain at least one small letter'})
        if not re.search(r'[0-9]', password):
            return render(request, 'signup.html', {'msg': 'Password must contain at least one number'})
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return render(request, 'signup.html', {'msg': 'Password must contain at least one special character'})

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        user = User(name=name, email=email, password=hashed_password.decode('utf-8'))
        user.save()

        msg = "You have signed up successfully"
        messages.success(request, msg)
        return redirect("login")
    else:
        return render(request, 'signup.html')

def resetPass(request):
    if request.method == "POST":
        code = request.POST.get("textToSend")
        request.session['codepy'] = code 
        email = request.POST.get("email")
        try:
            user = User.objects.get(email=email)
            messages.success(request, "Email found. Code has been sent.")
        except User.DoesNotExist:
            messages.error(request, "This email address is not registered!")
            return render(request, 'resetPass.html')
    return render(request, 'resetPass.html')

def verify(request):
    if request.method == "POST":
        code = request.POST.get("textToSend")
        codepy = request.session.get('codepy')
        if code == codepy:
            return redirect('confirm')
        else:
            messages.error(request, "Wrong code!")
            return redirect('confirm')
    return render(request, 'CodeVerification.html')

def confirm(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("pass")
        confirm_password = request.POST.get("conpass")

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, "User does not exist")
            return render(request, 'confirmPass.html')

        if len(password) < 8:
            return render(request, 'confirmPass.html', {'msg': 'Password must be at least 8 characters long'})
        if not re.search(r'[A-Z]', password):
            return render(request, 'confirmPass.html', {'msg': 'Password must contain at least one capital letter'})
        if not re.search(r'[a-z]', password):
            return render(request, 'confirmPass.html', {'msg': 'Password must contain at least one small letter'})
        if not re.search(r'[0-9]', password):
            return render(request, 'confirmPass.html', {'msg': 'Password must contain at least one number'})
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return render(request, 'confirmPass.html', {'msg': 'Password must contain at least one special character'})


        if password != confirm_password:
            messages.error(request, "Please enter the same password both times")
            return render(request, 'confirmPass.html')

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        user.password = hashed_password.decode('utf-8')
        user.save()
        
        messages.success(request, "Password updated successfully")
        return redirect('login')

    return render(request, 'confirmPass.html')


#------------------------------------------------------------------------------------------------------------
def category(request):
    emp = Category.objects.all()
    context = {
        'data': emp
    }
    return render(request, 'categories.html', context)

def add(request):
    if request.method == 'POST':
        name = request.POST.get('name')

        emp = Category(name=name)
        emp.save()
        return redirect("category")
    else:
        return render(request, 'categories.html')
    
def edit(request, id):
    emp = get_object_or_404(Category, id=id)
    if request.method == 'POST':
        emp.name = request.POST.get('name')
        emp.save()
        return redirect("category")
    else:
        context = {
            'emp': emp
        }
        return render(request, 'categories.html', context)
    
def delete(request, id):
    emp = get_object_or_404(Category, id=id)
    if request.method == 'POST':
        emp.delete()
        return redirect('category')
    return redirect('category')

def product(request):
    emp = Product.objects.all() 
    categories = Category.objects.all() 
    context = {
        'data': emp,
        'categories': categories
    }
    return render(request, 'products.html', context)

def prodadd(request):
    if request.method == 'POST':
        title = request.POST.get("title")
        brand = request.POST.get("brand")
        price = request.POST.get("price")
        qty = request.POST.get("quantity")
        desc = request.POST.get("desc")
        category_id = request.POST.get("category")
        profile_image = request.FILES.get('profile_image')

        category = Category.objects.get(id=category_id)
        product = Product(title=title, brand=brand, price=price, quantity=qty, description=desc, Category=category, profile_image=profile_image)
        product.save()
        return redirect("product")


def prodedit(request, id):
    emp = get_object_or_404(Product, id=id)
    
    if request.method == 'POST':
        emp.title = request.POST.get('title')
        emp.brand = request.POST.get('brand')
        emp.price = request.POST.get('price')
        emp.quantity = request.POST.get('quantity')
        emp.description = request.POST.get('desc')
        
        category_id = request.POST.get('category')
        category = get_object_or_404(Category, id=category_id)
        emp.Category = category
        
        if request.FILES.get('profile_image'):
            emp.profile_image = request.FILES.get('profile_image')
            
        emp.save()
        return redirect("product")
    else:
        context = {
            'emp': emp
        }
        return render(request, 'products.html', context)
    
def proddelete(request, id):
    emp = get_object_or_404(Product, id=id)
    if request.method == 'POST':
        emp.delete()
        return redirect('product')
    return redirect('product')
